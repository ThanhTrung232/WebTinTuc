<?php
    session_start();
    require_once "./mvc/bridge.php";
    $myapp  = new App();
?>