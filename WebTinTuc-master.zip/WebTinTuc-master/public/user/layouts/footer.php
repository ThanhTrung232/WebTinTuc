   <!---Footer----->


   <section class="footer-absolute">
    <div class="container-fluid all_footer_right_reserved">
        <div class="container">
            <div class="row  ">
                <div class="col-12 col-md-6 py-4 Reserved"> Trần Văn Nam </div>
                <div class="col-12 col-md-6 py-4 Reserved"> Trần Văn Nam </div>
                <div class="col-12 col-md-6 spdp_right py-4">
                    <a href="index.html" class="footer_last_part_menu">Home</a>
                    <a href="Contact_us.html" class="footer_last_part_menu">About</a>
                    <a href="Contact_us.html" class="footer_last_part_menu">Contact</a>
            </div>
        </div>
    </div>
</section>


<div class="gototop js-top">
    <a href="#" class="js-gotop"><i class="fa fa-arrow-up"></i></a>
</div>





     
    <script src="<?php echo URLROOT ?>/public/user/js/owl.carousel.min.js"></script>
    <!--<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"
            integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb"
            crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"
            integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn"
            crossorigin="anonymous"></script>
    <!-- Waypoints -->
    <script src="<?php echo URLROOT ?>/public/user/js/jquery.waypoints.min.js"></script>
    <!-- Main -->
    <script src="<?php echo URLROOT ?>/public/user/js/main.js"></script>
    <!-- Paging -->
    <script src="<?php echo URLROOT ?>/public/user/js/paging.js"></script>
    <!-- Search -->
    <script src="<?php echo URLROOT ?>/public/user/js/search.js"></script>

</body>
</html>