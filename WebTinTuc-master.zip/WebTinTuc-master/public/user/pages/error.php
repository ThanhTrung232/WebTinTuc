
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Not found 404!</title>
<style type="text/css">
#wapper{
	width:500px;
	height:auto;
	margin:0px auto
}
a{
	text-decoration:none;
	color:#00F
}
a:hover{
	color:#F30
}
</style>
</head>

<body>
<div id="wapper">
	<img src="<?php echo URLROOT;?>/public/images/error-404.jpg" alt="Not found 404" title="Not found 404" />
    <h3>Page Not Found</h3>
    <p align="right"><a href="<?php echo URLROOT;?>">Về Trang Chủ</a></p>
</div>
</body>
</html>